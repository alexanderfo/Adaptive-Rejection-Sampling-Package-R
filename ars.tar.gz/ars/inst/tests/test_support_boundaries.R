
f <- function(x) {return(x^(2-1) * (1-x)^(2-1))}
f <- function(x) {return(0)}
check_support_boundaries(f, 0.1, 0.4)
