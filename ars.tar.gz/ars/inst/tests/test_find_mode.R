library(testthat)
find_mode(dnorm)
dnorm(0)
